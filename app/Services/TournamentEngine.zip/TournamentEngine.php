<?php

namespace App\Services;

use App\Models\Game;
use App\Models\Tournament;

class TournamentEngine
{
    public function handleWin(Game $game, int $winnerId): void
    {
        $game->update([
            'winner_id' => $winnerId
        ]);

        if ($this->isGroupMatch($game)) {
            return;
        }

        $tournament = $game->tournament;
        $totalRounds = $this->getTotalRounds($tournament);

        /*
    |--------------------------------------------------------------------------
    | Platz-3-Spiel
    |--------------------------------------------------------------------------
    */

        if ($game->is_third_place) {

            $finalFinished = Game::where('tournament_id', $tournament->id)
                ->where('round', $totalRounds)
                ->where('is_third_place', false)
                ->whereNotNull('winner_id')
                ->exists();

            if ($finalFinished) {
                $tournament->update(['status' => 'finished']);
            }

            return;
        }

        /*
    |--------------------------------------------------------------------------
    | Finale
    |--------------------------------------------------------------------------
    */

        if ($game->round === $totalRounds) {

            if (!$tournament->has_third_place) {
                $tournament->update(['status' => 'finished']);
                return;
            }

            $thirdFinished = Game::where('tournament_id', $tournament->id)
                ->where('is_third_place', true)
                ->whereNotNull('winner_id')
                ->exists();

            if ($thirdFinished) {
                $tournament->update(['status' => 'finished']);
            }

            return;
        }

        /*
    |--------------------------------------------------------------------------
    | Normales KO-Spiel → Gewinner weiterleiten
    |--------------------------------------------------------------------------
    */

        $this->advanceWinner($game, $winnerId);

        if ($this->shouldCreateThirdPlace($game)) {
            $this->createThirdPlace($game);
        }
    }
}
