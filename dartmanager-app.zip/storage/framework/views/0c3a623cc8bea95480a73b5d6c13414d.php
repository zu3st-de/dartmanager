<?php
    /*
    |--------------------------------------------------------------------------
    | 📊 TABELLENBERECHNUNG
    |--------------------------------------------------------------------------
    |
    | Berechnet die aktuelle Rangliste der Gruppe:
    | - Punkte
    | - Siege / Niederlagen
    | - Differenz
    |
    | Wichtig:
    | Diese Daten werden bei jedem AJAX-Reload neu berechnet.
    |
    */
    $table = app(\App\Services\Group\GroupTableCalculator::class)->calculate($group);
?>

<table class="w-full text-xs text-gray-300 border border-gray-700 rounded-lg overflow-hidden">

    
    <thead class="bg-gray-800 text-gray-400 uppercase text-[10px] tracking-wider">
        <tr>
            <th>#</th>
            <th>Spieler</th>
            <th>Sp</th>
            <th>S</th>
            <th>N</th>
            <th>Diff</th>
            <th>Pkt</th>
        </tr>
    </thead>

    <tbody>

        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                /*
                |--------------------------------------------------------------------------
                | 🧠 STATUS LOGIK PRO SPIELER
                |--------------------------------------------------------------------------
                |
                | isQualified → kommt in die KO-Phase
                | isFirst     → Platz 1 (Gold / 🥇)
                | diff        → für farbliche Darstellung (+ grün / - rot)
                |
                */
                $isQualified = $index < $tournament->group_advance_count;
                $isFirst = $index === 0;
                $diff = $row['difference'];
            ?>

            <tr
                class="
                    
                    <?php echo e($isQualified ? 'bg-green-600/10' : 'bg-gray-900'); ?>


                    
                    hover:bg-gray-800 transition
                ">

                
                <td class="px-2 py-2 font-mono
                    <?php echo e($isFirst ? 'text-yellow-400 font-bold' : ''); ?>">
                    <?php echo e($index + 1); ?>

                </td>

                
                <td class="px-2 py-2
                    <?php echo e($isQualified ? 'text-green-400' : ''); ?>">

                    <?php if($isFirst): ?>
                        🥇
                    <?php endif; ?>

                    <?php echo e($row['player']->name); ?>

                </td>

                
                <td class="text-center">
                    <?php echo e($row['played']); ?>

                </td>

                
                <td class="text-center text-green-400">
                    <?php echo e($row['wins']); ?>

                </td>

                
                <td class="text-center text-red-400">
                    <?php echo e($row['losses']); ?>

                </td>

                
                <td
                    class="text-center font-mono
                    <?php echo e($diff > 0 ? 'text-green-400' : ($diff < 0 ? 'text-red-400' : 'text-gray-400')); ?>">

                    <?php echo e($diff > 0 ? '+' : ''); ?><?php echo e($diff); ?>

                </td>

                
                <td class="text-center font-bold
                    <?php echo e($isQualified ? 'text-green-400' : ''); ?>">
                    <?php echo e($row['points']); ?>

                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/_group_table.blade.php ENDPATH**/ ?>