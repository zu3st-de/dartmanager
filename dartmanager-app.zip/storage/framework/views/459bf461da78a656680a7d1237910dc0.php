<?php $__env->startSection('content'); ?>
    <div id="tvStage" class="w-screen h-screen relative"></div>


    <!-- Übersicht -->

    <div id="overviewTemplate" class="hidden">

        <div class="flex flex-col items-center justify-center h-screen w-full">


            <div class="flex justify-evenly items-center w-full max-w-6xl">

                <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col items-center">

                        <div class="text-3xl mb-6">
                            <?php echo e($tournament->name); ?>

                        </div>

                        
                        <div class="bg-white p-4 rounded">
                            <?php echo QrCode::size(444)->generate(url('/follow/' . $tournament->public_id)); ?>

                        </div>

                        
                        <?php if($tournament->children->where('type', 'lucky_loser')->first()): ?>
                            <?php
                                $lucky = $tournament->children->where('type', 'lucky_loser')->first();
                            ?>

                            <div class="text-yellow-400 text-xl mt-6 mb-2">
                                Lucky-Loser
                            </div>

                            <div class="bg-white p-3 rounded">
                                <?php echo QrCode::size(260)->generate(url('/follow/' . $lucky->id)); ?>

                            </div>
                        <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const rotationTime = <?php echo e(\App\Models\TvTournament::value('rotation_time') ?? 20); ?>;
        document.addEventListener("DOMContentLoaded", function() {

            const stage = document.getElementById("tvStage")

            const pages = [

                {
                    type: "overview"
                },

                <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        type: "tournament",
                        url: "/tv/<?php echo e($t->public_id); ?>"
                    },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            ]

            let index = 0


            function showPage() {

                const page = pages[index]

                stage.style.opacity = 0

                setTimeout(() => {

                    if (page.type === "overview") {

                        stage.innerHTML =
                            document.getElementById("overviewTemplate").innerHTML

                    } else {

                        stage.innerHTML =
                            `<iframe src="${page.url}" 
                    style="width:100%;height:100vh;border:none"></iframe>`

                    }

                    stage.style.opacity = 1

                }, 500)

            }


            function next() {

                index++

                if (index >= pages.length) {
                    index = 0
                }

                showPage()

            }


            showPage()

            setInterval(next, rotationTime * 1000)

        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        #tvStage {
            transition: opacity .6s ease;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.tv', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tv/rotation.blade.php ENDPATH**/ ?>