




<div class="space-y-10">

    <?php $__currentLoopData = $groupData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="group-block border-b border-gray-700 pb-8" data-group="<?php echo e($data['group']->id); ?>"
            data-players="<?php echo e($data['group']->players->pluck('id')->join(',')); ?>">

            <h4 class="text-lg font-semibold text-white mb-4">
                Gruppe <?php echo e($data['group']->name); ?>

            </h4>


            
            <div class="overflow-hidden rounded-lg border border-gray-700">

                <table class="w-full text-sm">

                    <thead class="bg-gray-800 text-gray-400 uppercase text-xs">
                        <tr>
                            <th>#</th>
                            <th>Spieler</th>
                            <th>Sp</th>
                            <th>S</th>
                            <th>N</th>
                            <th>Diff</th>
                            <th>Pkt</th>
                        </tr>
                    </thead>

                    <tbody class="group-table" data-group="<?php echo e($data['group']->id); ?>">

                        <?php $__currentLoopData = $data['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $diff = $row['difference'];
                            ?>

                            <tr class="group-row border-t border-gray-800" data-player="<?php echo e($row['player']->id); ?>"
                                data-group="<?php echo e($data['group']->id); ?>">

                                
                                <td
                                    class="rank px-2 py-2 font-mono <?php echo e($index === 0 ? 'text-yellow-400 font-bold' : ''); ?>">
                                    <?php echo e($index + 1); ?>

                                </td>

                                
                                <td
                                    class="name px-2 py-2 <?php echo e($index < $tournament->group_advance_count ? 'text-green-400' : ''); ?>">
                                    <?php if($index === 0): ?>
                                        🏆
                                    <?php endif; ?>
                                    <?php echo e($row['player']->name); ?>

                                </td>

                                
                                <td class="played text-center"><?php echo e($row['played']); ?></td>
                                <td class="wins text-center text-green-400"><?php echo e($row['wins']); ?></td>
                                <td class="losses text-center text-red-400"><?php echo e($row['losses']); ?></td>

                                
                                <td
                                    class="diff text-center font-mono
                                <?php echo e($diff > 0 ? 'text-green-400' : ($diff < 0 ? 'text-red-400' : 'text-gray-400')); ?>">
                                    <?php echo e($diff > 0 ? '+' : ''); ?><?php echo e($diff); ?>

                                </td>

                                
                                <td class="points text-center font-bold text-white">
                                    <?php echo e($row['points']); ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
            </div>


            
            <div class="mt-4 space-y-2 text-sm">

                <?php if($data['lastGame']): ?>
                    <div class="last-game text-sm" data-group="<?php echo e($data['group']->id); ?>">

                        <?php if($data['lastGame']): ?>
                            <strong>Letztes Spiel:</strong>

                            <?php echo e($data['lastGame']->player1->name); ?>

                            <?php echo e($data['lastGame']->player1_score); ?>

                            :
                            <?php echo e($data['lastGame']->player2_score); ?>

                            <?php echo e($data['lastGame']->player2->name); ?>

                        <?php endif; ?>

                    </div>
                <?php endif; ?>


                <?php if($data['currentGame']): ?>
                    <div class="current-game text-yellow-400 font-semibold" data-group="<?php echo e($data['group']->id); ?>">

                        <?php if($data['currentGame']): ?>
                            Jetzt am Board:
                            <?php echo e($data['currentGame']->player1?->name); ?>

                            vs
                            <?php echo e($data['currentGame']->player2?->name); ?>

                        <?php endif; ?>

                    </div>
                <?php endif; ?>


                <?php if($data['nextGame']): ?>
                    <div class="next-game text-gray-400" data-group="<?php echo e($data['group']->id); ?>">

                        <?php if($data['nextGame']): ?>
                            Nächstes Spiel:
                            <?php echo e($data['nextGame']->player1?->name); ?>

                            vs
                            <?php echo e($data['nextGame']->player2?->name); ?>

                        <?php endif; ?>

                    </div>
                <?php endif; ?>

            </div>


            
            <button id="toggleBtn<?php echo e($data['group']->id); ?>" onclick="toggleGroupGames(<?php echo e($data['group']->id); ?>)"
                class="mt-4 text-sm px-3 py-1 border border-gray-600 rounded text-gray-300 hover:bg-gray-800">

                Spiele anzeigen
            </button>


            
            <div id="groupGames<?php echo e($data['group']->id); ?>" class="group-games mt-4 hidden">

                <?php $__currentLoopData = $data['games']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="match-card border-b border-gray-800 py-2" data-match="<?php echo e($match->id); ?>"
                        data-player1="<?php echo e($match->player1_id); ?>" data-player2="<?php echo e($match->player2_id); ?>">

                        <div class="flex justify-between text-sm">

                            <span
                                class="<?php echo e($match->winner_id == $match->player1_id ? 'text-green-400 font-semibold' : ''); ?>">
                                <?php echo e($match->player1?->name); ?>

                            </span>

                            <span class="score text-gray-400">
                                <?php echo e($match->player1_score); ?> : <?php echo e($match->player2_score); ?>

                            </span>

                            <span
                                class="<?php echo e($match->winner_id == $match->player2_id ? 'text-green-400 font-semibold' : ''); ?>">
                                <?php echo e($match->player2?->name); ?>

                            </span>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>




<?php if($koRounds->count()): ?>

    <h4 class="text-xl font-semibold text-white mt-10 mb-4">
        KO Phase
    </h4>

    <?php $totalRounds = $koRounds->count(); ?>

    <?php $__currentLoopData = $koRounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roundNumber => $matches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $currentRoundIndex = $loop->index;
            $roundFromEnd = $totalRounds - $currentRoundIndex;
        ?>


        
        <?php if($roundFromEnd === 1 && $tournament->has_third_place && $thirdPlaceMatches->count()): ?>
            <div class="ko-round mb-6">

                <h5 class="text-gray-400 mb-2">
                    Spiel um Platz 3
                </h5>

                <?php $__currentLoopData = $thirdPlaceMatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="match-card border-b border-gray-800 py-2" data-match="<?php echo e($match->id); ?>"
                        data-player1="<?php echo e($match->player1_id); ?>" data-player2="<?php echo e($match->player2_id); ?>">

                        <div class="flex justify-between text-sm">

                            <span
                                class="<?php echo e($match->winner_id == $match->player1_id ? 'text-green-400 font-semibold' : ''); ?>">
                                <?php if($thirdPlace && $match->player1_id === $thirdPlace->id): ?>
                                    🥉
                                <?php endif; ?>
                                <?php echo e($match->player1->name ?? formatSource($match->player1_source)); ?>

                            </span>

                            <span class="score text-gray-400">
                                <?php echo e($match->player1_score); ?> : <?php echo e($match->player2_score); ?>

                            </span>

                            <span
                                class="<?php echo e($match->winner_id == $match->player2_id ? 'text-green-400 font-semibold' : ''); ?>">
                                <?php if($thirdPlace && $match->player2_id === $thirdPlace->id): ?>
                                    🥉
                                <?php endif; ?>
                                <?php echo e($match->player2->name ?? formatSource($match->player2_source)); ?>

                            </span>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endif; ?>


        
        <div class="ko-round mb-6">

            <h5 class="text-gray-400 mb-2">
                <?php echo e(koRoundName($matches->count())); ?>

            </h5>

            <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="match-card border-b border-gray-800 py-2" data-match="<?php echo e($match->id); ?>"
                    data-player1="<?php echo e($match->player1_id); ?>" data-player2="<?php echo e($match->player2_id); ?>">

                    <div class="flex justify-between text-sm">

                        <span
                            class="<?php echo e($match->winner_id == $match->player1_id ? 'text-green-400 font-semibold' : ''); ?>">

                            
                            <?php if($roundFromEnd === 1): ?>
                                <?php if($winner && $match->player1_id === $winner->id): ?>
                                    🥇
                                <?php elseif($secondPlace && $match->player1_id === $secondPlace->id): ?>
                                    🥈
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php echo e($match->player1->name ?? formatSource($match->player1_source, $roundFromEnd)); ?>


                        </span>

                        <span class="score text-gray-400">
                            <?php echo e($match->player1_score); ?> : <?php echo e($match->player2_score); ?>

                        </span>

                        <span
                            class="<?php echo e($match->winner_id == $match->player2_id ? 'text-green-400 font-semibold' : ''); ?>">

                            
                            <?php if($roundFromEnd === 1): ?>
                                <?php if($winner && $match->player2_id === $winner->id): ?>
                                    🥇
                                <?php elseif($secondPlace && $match->player2_id === $secondPlace->id): ?>
                                    🥈
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php echo e($match->player2->name ?? formatSource($match->player2_source, $roundFromEnd)); ?>


                        </span>

                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

<?php if($tournament->status === 'finished' && ($winner || $secondPlace || $thirdPlace)): ?>
    <div id="victoryOverlay" class="victory-overlay">

        <div class="victory-content">

            <div class="victory-title">
                🏆 Turniersieger 🏆
            </div>

            <div class="winner-name">
                <?php echo e($winner?->name); ?>

            </div>

            <div class="podium">

                
                <div class="place second">
                    <div class="name"><?php echo e($secondPlace?->name); ?></div>
                    <div class="step">🥈</div>
                </div>

                
                <div class="place first">
                    <div class="name"><?php echo e($winner?->name); ?></div>
                    <div class="step">🏆</div>
                </div>

                
                <div class="place third">
                    <div class="name"><?php echo e($thirdPlace?->name); ?></div>
                    <div class="step">🥉</div>
                </div>

            </div>

        </div>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/public/partials/follow-content.blade.php ENDPATH**/ ?>