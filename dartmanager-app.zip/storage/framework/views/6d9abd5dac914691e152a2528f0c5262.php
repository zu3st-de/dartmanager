<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Meine Turniere
        </h2>
     <?php $__env->endSlot(); ?>

    
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            
            <div class="mb-6">
                <a href="<?php echo e(route('tournaments.create')); ?>"
                    class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg">
                    + Neues Turnier
                </a>
            </div>

            
            <div class="bg-gray-900 dark:bg-gray-800 shadow rounded-xl p-6">

                
                <?php $__empty_1 = true; $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <div class="border-b border-gray-700 py-3">

                        
                        <div class="flex justify-between">

                            
                            <span class="text-lg text-white">
                                <a href="<?php echo e(route('tournaments.show', $tournament)); ?>"
                                    class="text-emerald-400 hover:underline">
                                    <?php echo e($tournament->name); ?>

                                </a>
                            </span>

                            
                            <span class="text-sm text-gray-400">
                                <?php echo e(ucfirst($tournament->status)); ?>

                            </span>

                        </div>
                        <?php if($tournament->status !== 'archived'): ?>
                            <form method="POST" action="<?php echo e(route('tournaments.archive.store', $tournament)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit">Archivieren</button>
                            </form>
                        <?php endif; ?>
                    </div>

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-400">
                        Noch keine Turniere vorhanden.
                    </p>
                <?php endif; ?>

            </div>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/index.blade.php ENDPATH**/ ?>