<div x-data="{ openReset: false, openResetKo: false }" x-init="<?php if($errors->getBag('reset')->has('confirm_name')): ?> openReset = true <?php endif; ?>

<?php if($errors->getBag('resetKo')->has('confirm_name')): ?> openResetKo = true <?php endif; ?>"
    class="h-full bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">
    <div class="flex flex-col lg:flex-row lg:items-center gap-4">

        
        <div class="text-lg font-semibold text-white whitespace-nowrap">
            Aktionen:
        </div>


        
        <div class="flex flex-wrap gap-3">

            
            <?php if($tournament->status === 'draft'): ?>
                
                <form method="POST" action="<?php echo e(route('tournaments.draw', $tournament)); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg text-white transition">
                        🎲 Auslosen
                    </button>
                </form>

                
                <?php
                    $canStart = $tournament->players->count() >= 2;
                ?>

                <form method="POST" action="<?php echo e(route('tournaments.start', $tournament)); ?>">
                    <?php echo csrf_field(); ?>

                    <button type="submit" <?php echo e(!$canStart ? 'disabled' : ''); ?>

                        class="
            px-4 py-2 rounded-lg text-white transition
            <?php echo e($canStart ? 'bg-green-600 hover:bg-green-500' : 'bg-gray-600 cursor-not-allowed opacity-50'); ?>

        "
                        title="<?php echo e($canStart ? '' : 'Mindestens 2 Spieler erforderlich'); ?>">
                        ▶ Starten
                    </button>
                </form>
            <?php endif; ?>



            <button onclick="showView('players')" data-tab="players"
                class="tab-btn pb-2 text-gray-400 hover:text-white transition">
                👤 Spieler
            </button>

            <button onclick="showView('groups')" data-tab="groups"
                class="tab-btn pb-2 text-gray-400 hover:text-white transition">
                🟢 Gruppen
            </button>

            <button onclick="showView('bracket')" data-tab="bracket"
                class="tab-btn pb-2 text-gray-400 hover:text-white transition">
                🏆 Bracket
            </button>

            <?php if(config('app.autosim_enabled') && in_array($tournament->status, ['group_running', 'ko_running'])): ?>
                <div class="autosim-panel">

                    <div class="autosim-row">
                        <label>Speed: <span id="autosimSpeedLabel">1500ms</span></label>
                        <input type="range" id="autosimSpeed" min="1000" max="3500" step="100"
                            value="1500">
                    </div>

                    <div class="autosim-row">
                        <button id="autosimStart">▶ Start</button>
                        <button id="autosimStop" disabled>⏹ Stop</button>
                    </div>

                    <div class="autosim-status" id="autosimStatus">
                        Status: Idle
                    </div>

                </div>
            <?php endif; ?>

            
            <?php if($tournament->status === 'group_running'): ?>
                <?php
                    $unfinished = $tournament->games->whereNotNull('group_id')->whereNull('winner_id')->count();

                    $canFinish = $unfinished === 0;
                ?>

                <form method="POST" action="<?php echo e(route('tournaments.finishGroups', $tournament)); ?>">
                    <?php echo csrf_field(); ?>

                    <button type="submit" <?php echo e(!$canFinish ? 'disabled' : ''); ?>

                        class="
                px-4 py-2 rounded-lg text-white transition
                <?php echo e($canFinish
                    ? 'bg-purple-600 hover:bg-purple-500'
                    : 'bg-gray-600 cursor-not-allowed opacity-50 hover:bg-gray-600'); ?>

            "
                        title="<?php echo e($canFinish ? '' : 'Gruppenspiele noch nicht vollständig'); ?>">
                        🏁 KO-Phase starten
                    </button>
                </form>
            <?php endif; ?>


            
            <?php if($tournament->status !== 'draft'): ?>
                <button type="button" @click="openReset = true"
                    class="bg-red-600 hover:bg-red-500 px-4 py-2 rounded-lg text-white transition">
                    ⛔ Reset
                </button>
            <?php endif; ?>


            
            <?php if($tournament->status === 'ko_running' && $tournament->mode === 'group_ko'): ?>
                <button type="button" @click="openResetKo = true"
                    class="bg-red-700 hover:bg-red-600 px-4 py-2 rounded-lg text-white">
                    🔁 KO-Phase zurücksetzen
                </button>
            <?php endif; ?>


            
            <?php if($tournament->status === 'finished'): ?>
                <form method="POST" action="<?php echo e(route('tournaments.reopen', $tournament)); ?>"
                    onsubmit="return confirm('Turnier wirklich wieder öffnen?');">
                    <?php echo csrf_field(); ?>
                    <button class="bg-yellow-600 hover:bg-yellow-500 px-4 py-2 rounded-lg text-white">
                        🔓 Turnier wieder öffnen
                    </button>
                </form>
            <?php endif; ?>

        </div>

    </div>


    
    <div x-show="openReset" x-transition class="fixed inset-0 bg-black/60 flex items-center justify-center z-50">

        <div class="bg-gray-900 p-6 rounded-xl border border-gray-700 w-full max-w-md">

            <h3 class="text-lg font-semibold text-white mb-4">
                Turnier wirklich zurücksetzen?
            </h3>

            <p class="text-sm text-gray-400 mb-4">
                Alle Spiele und Gruppen werden gelöscht.<br>
                Gib zur Bestätigung den Turniernamen ein:
            </p>

            <form method="POST" action="<?php echo e(route('tournaments.reset', $tournament)); ?>">
                <?php echo csrf_field(); ?>

                
                <?php $__errorArgs = ['confirm_name', 'reset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-400 text-sm mb-2">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <input type="text" name="confirm_name" value="<?php echo e(old('confirm_name')); ?>"
                    placeholder="<?php echo e($tournament->name); ?>"
                    class="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white mb-4" required>

                <div class="flex justify-end gap-3">
                    <button type="button" @click="openReset = false" class="bg-gray-700 px-4 py-2 rounded text-white">
                        Abbrechen
                    </button>

                    <button type="submit" class="bg-red-600 hover:bg-red-500 px-4 py-2 rounded text-white">
                        Endgültig zurücksetzen
                    </button>
                </div>
            </form>

        </div>
    </div>


    
    <div x-show="openResetKo" x-transition class="fixed inset-0 bg-black/60 flex items-center justify-center z-50">

        <div class="bg-gray-900 p-6 rounded-xl border border-gray-700 w-full max-w-md">

            <h3 class="text-lg font-semibold text-white mb-4">
                KO-Phase wirklich zurücksetzen?
            </h3>

            <p class="text-sm text-gray-400 mb-4">
                Alle KO-Spiele werden gelöscht.<br>
                Gruppenergebnisse bleiben erhalten.<br><br>
                Gib zur Bestätigung den Turniernamen ein:
            </p>

            <form method="POST" action="<?php echo e(route('tournaments.resetKo', $tournament)); ?>">
                <?php echo csrf_field(); ?>

                
                <?php $__errorArgs = ['confirm_name', 'resetKo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-400 text-sm mb-2">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <input type="text" name="confirm_name" value="<?php echo e(old('confirm_name')); ?>"
                    placeholder="<?php echo e($tournament->name); ?>"
                    class="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white mb-4" required>

                <div class="flex justify-end gap-3">
                    <button type="button" @click="openResetKo = false"
                        class="bg-gray-700 px-4 py-2 rounded text-white">
                        Abbrechen
                    </button>

                    <button type="submit" class="bg-red-600 hover:bg-red-500 px-4 py-2 rounded text-white">
                        KO-Phase zurücksetzen
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/actions.blade.php ENDPATH**/ ?>