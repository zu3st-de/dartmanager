<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-950 text-gray-200 min-h-screen flex items-center justify-center">

    <div class="text-center">

        <!-- Logo -->
        <div class="flex justify-center mb-8">
            <img src="<?php echo e(asset('images/logo.png')); ?>" class="h-80 w-auto" alt="Dart-Manager">
        </div>

        <!-- Buttons -->
        <div class="flex justify-center gap-4">

            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('tournaments.index')); ?>"
                    class="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white transition">
                    Zu den Turnieren
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>"
                    class="px-6 py-2 border border-gray-700 hover:bg-gray-800 rounded-lg transition">
                    Log in
                </a>
                <?php if(Route::has('register')): ?>

                    <a href="<?php echo e(route('register')); ?>"
                        class="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white transition">
                        Registrieren
                    </a>
                <?php endif; ?>
            <?php endif; ?>

        </div>

    </div>

</body>

</html><?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/welcome.blade.php ENDPATH**/ ?>