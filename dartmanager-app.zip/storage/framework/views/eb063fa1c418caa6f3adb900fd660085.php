<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-200">
            Neues Turnier erstellen
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-3xl mx-auto">

            <div class="bg-gray-900 shadow rounded-xl p-6">
                <form method="POST" action="<?php echo e(route('tournaments.store')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <?php if($errors->any()): ?>
                        <div class="mb-4 bg-red-600 text-white p-3 rounded-lg">
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>• <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    <div class="mb-4">
                        <label class="block text-gray-300 mb-2">Turniername</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                            class="w-full rounded-lg bg-gray-700 text-white border-gray-600 focus:ring-emerald-500">
                    </div>

                    
                    <div class="mb-4">
                        <label class="block text-gray-300 mb-2">Spielmodus</label>
                        <select name="mode"
                            class="w-full rounded-lg bg-gray-700 text-white border-gray-600 focus:ring-emerald-500">
                            <option value="ko" <?php echo e(old('mode') == 'ko' ? 'selected' : ''); ?>>KO-System</option>
                            <option value="group_ko" <?php echo e(old('mode') == 'group_ko' ? 'selected' : ''); ?>>Gruppenphase + KO
                            </option>
                        </select>
                    </div>

                    
                    <div id="group-settings" class="space-y-4 hidden">

                        <div>
                            <label class="block text-sm text-gray-300">
                                Anzahl Gruppen
                            </label>
                            <input type="number" name="group_count" min="1" value="<?php echo e(old('group_count')); ?>"
                                class="w-full bg-gray-700 text-white rounded px-3 py-2">
                        </div>

                        <div>
                            <label class="block text-sm text-gray-300">
                                Weiter pro Gruppe
                            </label>
                            <input type="number" name="group_advance_count" min="1"
                                value="<?php echo e(old('group_advance_count')); ?>"
                                class="w-full bg-gray-700 text-white rounded px-3 py-2">
                        </div>

                    </div>

                    
                    <div class="mb-4 flex items-center space-x-6">
                        <label class="flex items-center text-gray-300">
                            <input type="checkbox" name="has_lucky_loser" class="mr-2"
                                <?php echo e(old('has_lucky_loser') ? 'checked' : ''); ?>>
                            Lucky Loser
                        </label>

                        <label class="flex items-center text-gray-300">
                            <input type="checkbox" name="has_third_place" class="mr-2"
                                <?php echo e(old('has_third_place') ? 'checked' : ''); ?>>
                            Spiel um Platz 3
                        </label>
                    </div>

                    <div class="mt-6">
                        <button type="submit"
                            class="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg">
                            Turnier erstellen
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    
    <script>
        const modeSelect = document.querySelector('select[name="mode"]');
        const groupSettings = document.getElementById('group-settings');
        const groupInputs = groupSettings.querySelectorAll('input');

        function toggleGroupSettings() {
            if (modeSelect.value === 'group_ko') {
                groupSettings.classList.remove('hidden');
                groupInputs.forEach(input => input.required = true);
            } else {
                groupSettings.classList.add('hidden');
                groupInputs.forEach(input => input.required = false);
            }
        }

        modeSelect.addEventListener('change', toggleGroupSettings);
        toggleGroupSettings();
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-200">
            Neues Turnier erstellen
        </h2>
     <?php $__env->endSlot(); ?>

    
    <div class="py-8">
        <div class="max-w-3xl mx-auto">

            
            <div class="bg-gray-900 shadow rounded-xl p-6">
                <form method="POST" action="<?php echo e(route('tournaments.store')); ?>">
                    <?php echo csrf_field(); ?> 

                    
                    <?php if($errors->any()): ?>
                        <div class="mb-4 bg-red-600 text-white p-3 rounded-lg">
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>• <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    <div class="mb-4">
                        <label class="block text-gray-300 mb-2">Turniername</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                            class="w-full rounded-lg bg-gray-700 text-white border-gray-600 focus:ring-emerald-500">
                    </div>

                    
                    <div class="mb-4">
                        <label class="block text-gray-300 mb-2">Spielmodus</label>
                        <select name="mode"
                            class="w-full rounded-lg bg-gray-700 text-white border-gray-600 focus:ring-emerald-500">

                            
                            <option value="ko" <?php echo e(old('mode') == 'ko' ? 'selected' : ''); ?>>
                                KO-System
                            </option>

                            
                            <option value="group_ko" <?php echo e(old('mode') == 'group_ko' ? 'selected' : ''); ?>>
                                Gruppenphase + KO
                            </option>
                        </select>
                    </div>

                    
                    
                    <div id="group-settings" class="space-y-4 hidden">

                        
                        <div>
                            <label class="block text-sm text-gray-300">
                                Anzahl Gruppen
                            </label>
                            <input type="number" name="group_count" min="1" value="<?php echo e(old('group_count')); ?>"
                                class="w-full bg-gray-700 text-white rounded px-3 py-2">
                        </div>

                        
                        <div>
                            <label class="block text-sm text-gray-300">
                                Weiter pro Gruppe
                            </label>
                            <input type="number" name="group_advance_count" min="1"
                                value="<?php echo e(old('group_advance_count')); ?>"
                                class="w-full bg-gray-700 text-white rounded px-3 py-2">
                        </div>

                    </div>

                    
                    <div class="mb-4 flex items-center space-x-6">

                        
                        <label class="flex items-center text-gray-300">
                            <input type="checkbox" name="has_lucky_loser" class="mr-2"
                                <?php echo e(old('has_lucky_loser') ? 'checked' : ''); ?>>
                            Lucky Loser
                        </label>

                        
                        <label class="flex items-center text-gray-300">
                            <input type="checkbox" name="has_third_place" class="mr-2"
                                <?php echo e(old('has_third_place') ? 'checked' : ''); ?>>
                            Spiel um Platz 3
                        </label>
                    </div>

                    
                    <div class="mt-6">
                        <button type="submit"
                            class="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg">
                            Turnier erstellen
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    
    <script>
        // Referenz auf das Select-Feld für den Modus
        const modeSelect = document.querySelector('select[name="mode"]');

        // Container mit den Gruppen-Einstellungen
        const groupSettings = document.getElementById('group-settings');

        // Alle Input-Felder innerhalb der Gruppen-Einstellungen
        const groupInputs = groupSettings.querySelectorAll('input');

        // Funktion zum Ein-/Ausblenden der Gruppenoptionen
        function toggleGroupSettings() {

            // Wenn Gruppenmodus aktiv
            if (modeSelect.value === 'group_ko') {

                // Anzeigen
                groupSettings.classList.remove('hidden');

                // Felder als Pflicht markieren
                groupInputs.forEach(input => input.required = true);

            } else {

                // Ausblenden
                groupSettings.classList.add('hidden');

                // Pflicht entfernen
                groupInputs.forEach(input => input.required = false);
            }
        }

        // EventListener: reagiert auf Änderung des Modus
        modeSelect.addEventListener('change', toggleGroupSettings);

        // Initialer Aufruf (z.B. nach Validation-Fehlern wichtig)
        toggleGroupSettings();
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/create.blade.php ENDPATH**/ ?>