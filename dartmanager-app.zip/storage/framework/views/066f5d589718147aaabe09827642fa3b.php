

<div data-group-games="<?php echo e($group->id); ?>">

    <?php $__currentLoopData = $group->games->sortBy(fn($g) => $g->winner_id ? 1 : 0)->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php echo $__env->make('tournaments.partials._group_game_single', [
            'game' => $game,
            'tournament' => $tournament,
            'group' => $group,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/_group_games.blade.php ENDPATH**/ ?>