<?php
    /*
|--------------------------------------------------------------------------
| 🧮 GRUNDLAGEN BERECHNEN
|--------------------------------------------------------------------------
*/

    // Höchste Runde im KO (Finale)
    $maxRound = $tournament->games->whereNull('group_id')->max('round');

    // Finale (kein Spiel um Platz 3)
    $final = $tournament->games->where('round', $maxRound)->where('is_third_place', false)->first();

    // Spiel um Platz 3
    $thirdPlaceGame = $tournament->games->where('round', $maxRound)->where('is_third_place', true)->first();

    /*
|--------------------------------------------------------------------------
| 🏆 PLATZIERUNGEN INITIALISIEREN
|--------------------------------------------------------------------------
*/
    $first = null;
    $second = null;
    $third = null;

    /*
|--------------------------------------------------------------------------
| 🥇🥈 PLATZ 1 & 2 AUS FINALE BESTIMMEN
|--------------------------------------------------------------------------
*/
    if ($final && $final->winner_id) {
        // Gewinner des Finales = Platz 1
        $first = $final->winner;

        // Verlierer des Finales = Platz 2
        $second = $final->winner_id == $final->player1_id ? $final->player2 : $final->player1;
    }

    /*
|--------------------------------------------------------------------------
| 🥉 PLATZ 3 AUS EXTRA-SPIEL
|--------------------------------------------------------------------------
*/
    if ($thirdPlaceGame && $thirdPlaceGame->winner_id) {
        $third = $thirdPlaceGame->winner;
    }
?>


<?php if($tournament->status === 'finished' && $first): ?>

    <div class="bg-gray-900 border border-gray-800 rounded-xl p-8 shadow-xl mt-8">

        
        <h2 class="text-center text-xl font-semibold text-white mb-8">
            🏆 Turnierergebnis
        </h2>

        
        <div class="flex justify-center items-end gap-6">

            
            <?php if($second): ?>
                <div class="flex flex-col items-center">

                    
                    <div class="bg-gray-700 text-gray-200 px-6 py-3 rounded-t-lg font-semibold shadow">
                        🥈 <?php echo e($second->name); ?>

                    </div>

                    
                    <div class="bg-gray-600 w-24 h-20 rounded-b-lg"></div>
                </div>
            <?php endif; ?>

            
            <div class="flex flex-col items-center">

                
                <div class="bg-yellow-500 text-gray-900 px-8 py-4 rounded-t-lg font-bold text-lg shadow-lg scale-110">
                    🏆 <?php echo e($first->name); ?>

                </div>

                
                <div class="bg-yellow-600 w-28 h-28 rounded-b-lg"></div>
            </div>

            
            <?php if($tournament->has_third_place && $third): ?>
                <div class="flex flex-col items-center">

                    
                    <div class="bg-amber-600 text-white px-6 py-3 rounded-t-lg font-semibold shadow">
                        🥉 <?php echo e($third->name); ?>

                    </div>

                    
                    <div class="bg-amber-700 w-24 h-16 rounded-b-lg"></div>
                </div>
            <?php endif; ?>

        </div>

    </div>

<?php endif; ?>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/winner.blade.php ENDPATH**/ ?>