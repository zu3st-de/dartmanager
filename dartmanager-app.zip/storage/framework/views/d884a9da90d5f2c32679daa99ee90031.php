<?php
    $bestOf = (int) ($game->best_of ?? 1);
?>

<div class="game-wrapper mb-4" data-game="<?php echo e($game->id); ?>" data-group="<?php echo e($game->group_id); ?>"
    data-finished="<?php echo e($game->winner_id ? '1' : '0'); ?>">

    <div class="bg-gray-800 border border-gray-700 rounded-lg p-4 shadow min-w-[240px] relative">

        
        <?php if(!$game->winner_id && $tournament->status === 'group_running'): ?>

            
            <button type="submit" form="game-form-<?php echo e($game->id); ?>"
                class="save-btn absolute top-2 right-2 text-green-400 hover:text-green-300 text-sm z-10">
                ✅
            </button>

            <form id="game-form-<?php echo e($game->id); ?>" method="POST" action="<?php echo e(route('games.score', $game)); ?>"
                data-url="<?php echo e(route('games.score', $game)); ?>" data-bestof="<?php echo e($game->best_of); ?>"
                data-group="<?php echo e($game->group_id); ?>" data-game="<?php echo e($game->id); ?>"
                class="score-form group-score-form simulate-group-form">

                <?php echo csrf_field(); ?>

                
                <div class="space-y-3 mt-4 text-sm">

                    
                    <div class="flex justify-between items-center px-3 h-10 rounded border border-gray-700 bg-gray-900">
                        <span>
                            <?php echo e($game->player1->name ?? '-'); ?>

                        </span>

                        <input type="number" name="player1_score" min="0"
                            class="group-score-input w-12 h-8 bg-transparent border-0 text-center rounded text-white focus:outline-none focus:ring-1 focus:ring-gray-500">
                    </div>

                    
                    <div class="flex justify-between items-center px-3 h-10 rounded border border-gray-700 bg-gray-900">
                        <span>
                            <?php echo e($game->player2->name ?? '-'); ?>

                        </span>

                        <input type="number" name="player2_score" min="0"
                            class="group-score-input w-12 h-8 bg-transparent border-0 text-center rounded text-white focus:outline-none focus:ring-1 focus:ring-gray-500">
                    </div>

                    
                    <?php if($bestOf === 1): ?>
                        <div class="flex justify-between items-center text-xs text-gray-400">
                            <span>Rest</span>

                            <input type="number" name="winning_rest" min="0" max="501"
                                class="w-16 h-8 bg-transparent border border-gray-600 rounded text-center text-white focus:outline-none focus:border-green-500">
                        </div>
                    <?php endif; ?>

                </div>

            </form>


            
        <?php else: ?>
            
            <?php
                $canReset = $game->canBeReset();
            ?>

            <?php if($canReset): ?>
                <button type="submit" form="reset-form-<?php echo e($game->id); ?>"
                    class="absolute top-2 right-2 text-red-500 hover:text-red-400 text-sm">
                    🗑
                </button>

                <form id="reset-form-<?php echo e($game->id); ?>" method="POST" action="<?php echo e(route('games.reset', $game)); ?>"
                    class="hidden">
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>

            <?php
                $p1Winner = (int) $game->winner_id === (int) $game->player1_id;
                $p2Winner = (int) $game->winner_id === (int) $game->player2_id;
            ?>

            <div class="space-y-3 mt-4 text-sm">

                
                <div
                    class="flex justify-between items-center px-3 h-10 rounded border
                    <?php echo e($p1Winner ? 'bg-green-600/20 border-green-500/40' : 'bg-gray-900 border-gray-700 opacity-70'); ?>">

                    <span class="<?php echo e($p1Winner ? 'text-green-400 font-semibold' : 'text-gray-400'); ?>">
                        <?php echo e($game->player1->name ?? '-'); ?>

                    </span>

                    <span class="font-mono">
                        <?php echo e($game->player1_score ?? '-'); ?>

                    </span>
                </div>

                
                <div
                    class="flex justify-between items-center px-3 h-10 rounded border
                    <?php echo e($p2Winner ? 'bg-green-600/20 border-green-500/40' : 'bg-gray-900 border-gray-700 opacity-70'); ?>">

                    <span class="<?php echo e($p2Winner ? 'text-green-400 font-semibold' : 'text-gray-400'); ?>">
                        <?php echo e($game->player2->name ?? '-'); ?>

                    </span>

                    <span class="font-mono">
                        <?php echo e($game->player2_score ?? '-'); ?>

                    </span>
                </div>

                
                <?php if($bestOf === 1 && $game->winning_rest !== null): ?>
                    <div class="text-xs text-gray-400 text-center">
                        Rest: <?php echo e($game->winning_rest); ?>

                    </div>
                <?php endif; ?>

            </div>

        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/_group_game_single.blade.php ENDPATH**/ ?>