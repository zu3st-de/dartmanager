<img src="<?php echo e(asset('images/logo.png')); ?>"
    <?php echo e($attributes->merge(['class' => 'h-80 w-auto'])); ?>

    alt="Dart-Manager"><?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>