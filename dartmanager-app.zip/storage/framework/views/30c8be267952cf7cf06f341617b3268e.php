<div class="game-wrapper" data-game-id="<?php echo e($game->id); ?>">

    <?php echo $__env->make('tournaments.partials._ko_game_inner', [
        'game' => $game,
        'tournament' => $tournament,
        'maxRound' => $maxRound ?? null,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/_ko_game.blade.php ENDPATH**/ ?>