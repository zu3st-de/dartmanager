<?php $__env->startSection('content'); ?>
    <div class="mb-10 text-center">

        <h1 class="text-4xl font-bold text-white">
            <?php echo e($tournament->name); ?>

        </h1>

    </div>
    <div class="flex justify-center w-full">
        <div class="flex flex-wrap justify-center gap-10 max-w-[1800px] mx-auto">

            <?php $__currentLoopData = $groupData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg w-[420px]"
                    data-group="<?php echo e($data['group']->id); ?>">

                    <div class="text-xl font-semibold text-white mb-6">
                        Gruppe <?php echo e($data['group']->name); ?>

                    </div>


                    
                    <div class="overflow-hidden rounded-lg border border-gray-700">

                        <table class="w-full text-base text-gray-300">

                            <thead class="bg-gray-800 text-gray-400 uppercase text-xs tracking-wider">

                                <tr>
                                    <th class="px-2 py-2 text-left w-6">#</th>
                                    <th class="px-2 py-2 text-left">Spieler</th>
                                    <th class="px-2 py-2 text-center w-8">Sp</th>
                                    <th class="px-2 py-2 text-center w-8">S</th>
                                    <th class="px-2 py-2 text-center w-8">N</th>
                                    <th class="px-2 py-2 text-center w-10">Diff</th>
                                    <th class="px-2 py-2 text-center w-10">Pkt</th>
                                </tr>

                            </thead>

                            <tbody>

                                <?php $__currentLoopData = $data['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $isQualified = $index < $tournament->group_advance_count;
                                        $isFirst = $index === 0;
                                        $diff = $row['difference'];
                                    ?>

                                    <tr
                                        class="
                <?php echo e($isQualified ? 'bg-green-600/10' : 'bg-gray-900'); ?>

                border-t border-gray-800
            ">

                                        
                                        <td
                                            class="px-2 py-2 font-mono
                    <?php echo e($isFirst ? 'text-yellow-400 font-bold' : ''); ?>">
                                            <?php echo e($index + 1); ?>

                                        </td>


                                        
                                        <td
                                            class="px-2 py-2
                    <?php echo e($isQualified ? 'text-green-400' : ''); ?>">

                                            <?php if($isFirst): ?>
                                                🏆
                                            <?php endif; ?>

                                            <?php echo e($row['player']->name); ?>


                                        </td>


                                        <td class="px-2 py-2 text-center">
                                            <?php echo e($row['played']); ?>

                                        </td>

                                        <td class="px-2 py-2 text-center text-green-400">
                                            <?php echo e($row['wins']); ?>

                                        </td>

                                        <td class="px-2 py-2 text-center text-red-400">
                                            <?php echo e($row['losses']); ?>

                                        </td>


                                        
                                        <td
                                            class="px-2 py-2 text-center font-mono
                    <?php echo e($diff > 0 ? 'text-green-400' : ($diff < 0 ? 'text-red-400' : 'text-gray-400')); ?>">
                                            <?php echo e($diff > 0 ? '+' : ''); ?><?php echo e($diff); ?>

                                        </td>


                                        
                                        <td class="px-2 py-2 text-center font-bold text-white">
                                            <?php echo e($row['points']); ?>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </div>


                    
                    <?php if($data['lastGame']): ?>
                        <?php
                            $game = $data['lastGame'];

                            $p1Winner = $game->winner_id === $game->player1_id;
                            $p2Winner = $game->winner_id === $game->player2_id;
                        ?>

                        <div class="mt-6 text-xs text-gray-400 uppercase tracking-wider">
                            Letztes Spiel
                        </div>

                        <div class="flex justify-between text-lg mb-4">

                            <span class="<?php echo e($p1Winner ? 'text-green-400 font-semibold' : ''); ?>">
                                <?php echo e($game->player1->name); ?>

                            </span>

                            <span class="font-mono">
                                <?php echo e($game->player1_score); ?>

                                -
                                <?php echo e($game->player2_score); ?>

                            </span>

                            <span class="<?php echo e($p2Winner ? 'text-green-400 font-semibold' : ''); ?>">
                                <?php echo e($game->player2->name); ?>

                            </span>

                        </div>
                    <?php endif; ?>


                    
                    <?php if($data['currentGame']): ?>
                        <div class="text-xs text-yellow-400 uppercase tracking-wider">
                            Jetzt am Board
                        </div>

                        <div class="flex justify-between text-xl font-semibold text-yellow-300 mb-4">

                            <span>
                                <?php echo e($data['currentGame']->player1->name ?? 'TBD'); ?>

                            </span>

                            <span class="text-gray-400">
                                vs
                            </span>

                            <span>
                                <?php echo e($data['currentGame']->player2->name ?? 'TBD'); ?>

                            </span>

                        </div>
                    <?php endif; ?>


                    
                    <?php if($data['nextGame']): ?>
                        <div class="text-xs text-gray-400 uppercase tracking-wider">
                            Nächstes Spiel
                        </div>

                        <div class="flex justify-between text-lg">

                            <span>
                                <?php echo e($data['nextGame']->player1->name ?? 'TBD'); ?>

                            </span>

                            <span class="text-gray-500">
                                vs
                            </span>

                            <span>
                                <?php echo e($data['nextGame']->player2->name ?? 'TBD'); ?>

                            </span>

                        </div>
                    <?php endif; ?>


                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tv', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tv/show.blade.php ENDPATH**/ ?>