<!DOCTYPE html>
<html lang="de" class="dark">

<head>

    <meta charset="utf-8">
    <title><?php echo e($tournament->name ?? 'Turnier TV'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>

<body class="bg-gray-950 text-gray-200 min-h-screen overflow-hidden">

    <div class="p-10">

        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/layouts/tv.blade.php ENDPATH**/ ?>