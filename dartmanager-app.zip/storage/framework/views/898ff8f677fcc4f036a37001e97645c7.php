<div class="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">

    
    <div class="flex items-center justify-between mb-4">

        <h2 class="text-xl font-bold">Gruppenphase</h2>

        
        <select onchange="updateGroupBestOf(this, <?php echo e($tournament->id); ?>)"
            class="bg-gray-800 text-xs rounded border border-gray-700 
                       text-emerald-400 px-2 py-1">

            <?php $__currentLoopData = [1, 3, 5, 7]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php echo e($groupBestOf == $value ? 'selected' : ''); ?>>
                    Bo<?php echo e($value); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

    </div>

    
    <div class="flex gap-8 flex-wrap">

        <?php $__currentLoopData = $tournament->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="min-w-[320px]" data-group="<?php echo e($group->id); ?>">

                
                <h3 class="text-sm text-gray-400 mb-4">
                    Gruppe <?php echo e($group->name); ?>

                </h3>

                
                <div class="group-table mb-6" data-group-table="<?php echo e($group->id); ?>">

                    <?php echo $__env->make('tournaments.partials._group_table', [
                        'group' => $group,
                        'tournament' => $tournament,
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                </div>

                
                <div data-group-games="<?php echo e($group->id); ?>"
                    class="group-scroll max-h-[400px] overflow-y-auto pr-2 space-y-3 scroll-smooth">

                    <?php echo $__env->make('tournaments.partials._group_games', [
                        'group' => $group,
                        'tournament' => $tournament,
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/groups.blade.php ENDPATH**/ ?>