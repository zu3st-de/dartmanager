<nav class="bg-gray-900 border-b border-gray-800 px-6 py-3">
    <div class="flex items-center justify-between">

        
        <div class="flex items-center gap-8">

            
            <a href="<?php echo e(route('tournaments.index')); ?>" class="flex items-center gap-3">

                <img src="<?php echo e(asset('images/dart-manager-horizontal-normal.png')); ?>"
                    srcset="<?php echo e(asset('images/dart-manager-horizontal@2x.png')); ?> 2x" height="50"
                    alt="Dart Manager Logo">

            </a>

            
            <a href="<?php echo e(route('tournaments.index')); ?>"
                class="text-gray-300 hover:text-white text-sm font-semibold transition">
                Alle Turniere
            </a>
            <a href="/admin/tv" class="nav-link">
                TV Admin
            </a>
            <a href="/tv" class="nav-link">
                TV Rotation
            </a>
            <a href="<?php echo e(route('tournaments.archive')); ?>" class="text-gray-400 hover:text-white text-sm">
                📦 Archiv
            </a>
            
            <?php $__currentLoopData = $activeTournaments ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('tournaments.show', $tournament)); ?>"
                    class="text-gray-400 hover:text-emerald-400 text-sm transition">

                    <?php echo e($tournament->name); ?>


                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        
        <div class="flex items-center gap-4">

            <?php if(auth()->guard()->check()): ?>
                <span class="text-gray-400 text-sm">
                    <?php echo e(auth()->user()->name); ?>

                </span>

                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-gray-400 hover:text-red-400 text-sm transition">
                        Logout
                    </button>
                </form>
            <?php endif; ?>

        </div>

    </div>
</nav>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>