<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="space-y-8 py-8">

        
        <div class="h-full grid grid-cols-1 lg:grid-cols-3 gap-8">

            <!-- 🔹 Turnier-Header (1/3) -->
            <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">

                
                <div class="flex justify-between items-center">

                    
                    <h1 class="text-2xl font-semibold text-white">
                        <?php echo e($tournament->name); ?>

                    </h1>

                    
                    <span
                        class="px-3 py-1 text-xs rounded-full

                            
                            <?php if($tournament->status === 'draft'): ?> bg-yellow-500/20 text-yellow-400

                            
                            <?php elseif($tournament->status === 'group_running'): ?> 
                                bg-blue-500/20 text-blue-400

                            
                            <?php elseif($tournament->status === 'ko_running'): ?> 
                                bg-purple-500/20 text-purple-400

                            
                            <?php elseif($tournament->status === 'finished'): ?> 
                                bg-green-500/20 text-green-400 <?php endif; ?>
                        ">

                        
                        <?php echo e(ucfirst(str_replace('_', ' ', $tournament->status))); ?>

                    </span>
                </div>

                
                <div class="text-gray-400 mt-2 text-sm">
                    Modus: <?php echo e($tournament->mode); ?>

                </div>

            </div>

            <!-- 🔹 Actions-Bereich (2/3) -->
            <div class="lg:col-span-2">

                
                <?php echo $__env->make('tournaments.partials.actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>

        </div>

        

        
        <div id="view-players" class="view-section">
            <?php echo $__env->make('tournaments.partials.players', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <div id="view-groups" class="view-section hidden">

            <?php if($tournament->status !== 'draft'): ?>
                <?php echo $__env->make('tournaments.partials.groups', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <div class="text-gray-400 text-center py-10">
                    Gruppenphase noch nicht verfügbar
                </div>
            <?php endif; ?>

        </div>

        <div id="view-bracket" class="view-section hidden">

            <?php if($tournament->status !== 'draft'): ?>
                <?php echo $__env->make('tournaments.partials.knockout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <div class="text-gray-400 text-center py-10">
                    KO-Phase noch nicht gestartet
                </div>
            <?php endif; ?>

        </div>

        
        <?php echo $__env->make('tournaments.partials.winner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    window.tournamentId = <?php echo e($tournament->id); ?>;
    window.tournamentStatus = "<?php echo e($tournament->status); ?>";
</script>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/show.blade.php ENDPATH**/ ?>