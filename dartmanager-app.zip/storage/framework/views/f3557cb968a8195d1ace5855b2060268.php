
<div x-show="showPlayers" x-transition>

    
    <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">

        
        <h2 id="player-count" data-count="<?php echo e($tournament->players->count()); ?>"
            class="text-lg font-semibold mb-4 text-white">

            Teilnehmer (<?php echo e($tournament->players->count()); ?>)
        </h2>

        
        <div id="playersList" class="space-y-2 mb-4">

            
            <?php $__currentLoopData = $tournament->players->sortBy('seed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div x-data="{ editing: false }"
                    class="bg-gray-800 rounded-lg px-3 py-2 border border-gray-700 flex justify-between items-center">

                    
                    <div class="flex justify-between items-center w-full" x-show="!editing">

                        <div class="flex items-center gap-3">

                            
                            <span class="bg-blue-600 text-white text-xs px-2 py-1 rounded">
                                #<?php echo e($player->seed ?? '-'); ?>

                            </span>

                            
                            <span class="text-white">
                                <?php echo e($player->name); ?>

                            </span>

                        </div>

                        
                        <div class="flex gap-2">

                            
                            <button @click="editing = true" class="text-yellow-400 hover:text-yellow-300 text-sm">
                                ✏️
                            </button>

                            
                            <?php if($tournament->status === 'draft'): ?>
                                <form action="<?php echo e(route('players.destroy', $player)); ?>" method="POST"
                                    onsubmit="return confirm('Spieler wirklich löschen?');">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="text-red-500 hover:text-red-400 text-sm">
                                        ❌
                                    </button>
                                </form>
                            <?php endif; ?>

                        </div>
                    </div>

                    
                    <form x-show="editing" x-transition action="<?php echo e(route('players.update', $player)); ?>" method="POST"
                        class="flex gap-2 items-center w-full">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        
                        <input type="text" name="name" value="<?php echo e($player->name); ?>"
                            class="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-white text-sm w-full focus:ring-2 focus:ring-blue-500 focus:outline-none"
                            autofocus>

                        
                        <button type="submit" class="text-green-400 hover:text-green-300 text-sm">
                            💾
                        </button>

                        
                        <button type="button" @click="editing = false"
                            class="text-gray-400 hover:text-gray-300 text-sm">
                            ✖
                        </button>
                    </form>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <?php if($tournament->status === 'draft'): ?>
            
            <form id="playerForm" data-url="<?php echo e(route('tournaments.players.store', $tournament)); ?>" class="flex gap-2">

                <input type="text" id="playerInput" placeholder="Spielername eingeben" required autocomplete="off"
                    class="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none">

                <button type="submit" class="bg-blue-600 hover:bg-blue-500 transition px-4 py-2 rounded-lg text-white">
                    Hinzufügen
                </button>

            </form>

            
            <div class="mt-4">

                <label class="block text-sm text-gray-400 mb-2">
                    Mehrere Spieler einfügen (eine Zeile pro Spieler)
                </label>

                <form method="POST" action="<?php echo e(route('tournaments.players.bulk', $tournament)); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <textarea name="bulk_players" rows="6" placeholder="Max Mustermann
Peter Schmidt
Lisa Müller"
                        class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"></textarea>

                    
                    <button type="submit" class="mt-3 bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg text-white">
                        📋 Liste importieren
                    </button>
                </form>

            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\Users\simon\Documents\dartmanager-app\resources\views/tournaments/partials/players.blade.php ENDPATH**/ ?>